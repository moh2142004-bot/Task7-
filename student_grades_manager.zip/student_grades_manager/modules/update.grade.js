const { readGrades } = require("./read.grades");
const saveGrades = require("./save.grades");

function updateGrade(id, newGrade) {
    const grades = readGrades();

    const record = grades.find(r => r.id === id);

    if (!record) {
        console.log(`No record found with ID ${id}`);
        return;
    }

    const oldGrade = record.grade;
    record.grade = newGrade;

    saveGrades(grades);
    console.log(`Updated ${record.name}'s grade in ${record.subject}: ${oldGrade} -> ${newGrade}`);
}

module.exports = updateGrade;
