const { readGrades } = require("./read.grades");
const saveGrades = require("./save.grades");

function deleteGrade(identifier) {
    const grades = readGrades();

    const index = grades.findIndex(record =>
        record.id === identifier || record.name === identifier
    );

    if (index === -1) {
        console.log(`No record found matching "${identifier}"`);
        return;
    }

    const removedRecord = grades[index];
    grades.splice(index, 1);

    saveGrades(grades);
    console.log(`Deleted: ${removedRecord.name} | ${removedRecord.subject} | ${removedRecord.grade}`);
}

module.exports = deleteGrade;
