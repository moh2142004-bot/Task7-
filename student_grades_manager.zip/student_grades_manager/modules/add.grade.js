const { readGrades } = require("./read.grades");
const saveGrades = require("./save.grades");

function addGrade(name, subject, grade) {
    if (!name || !subject || grade === undefined) {
        console.log("Name, subject and grade are required");
        return;
    }

    const grades = readGrades();

    const newId = grades.length > 0
        ? Math.max(...grades.map(record => record.id)) + 1
        : 1;

    const newRecord = { id: newId, name, subject, grade };
    grades.push(newRecord);

    saveGrades(grades);
    console.log(`Added: ${name} | ${subject} | ${grade} (ID: ${newId})`);
}

module.exports = addGrade;
