const fs = require("fs");
const path = require("path");

const filePath = path.join(__dirname, "..", "data", "grades.json");

function readGrades() {
    try {
        const data = fs.readFileSync(filePath, "utf-8");
        return JSON.parse(data);
    } catch (error) {
        console.log("Error reading grades:", error.message);
        return [];
    }
}

function displayGrades() {
    const grades = readGrades();

    if (grades.length === 0) {
        console.log("No grade records found");
        return;
    }

    console.log("All student grades:");
    grades.forEach(record => {
        console.log(`- ID: ${record.id} | Name: ${record.name} | Subject: ${record.subject} | Grade: ${record.grade}`);
    });
}

module.exports = { readGrades, displayGrades };
