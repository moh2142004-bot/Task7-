const addGrade = require("./modules/add.grade");
const deleteGrade = require("./modules/delete.grade");
const updateGrade = require("./modules/update.grade");
const { displayGrades } = require("./modules/read.grades");

console.log("----- Adding grades -----");
addGrade("Esraa", "Math", 90);
addGrade("Ahmed", "Science", 75);
addGrade("Sara", "English", 60);

console.log("\n----- Current grades -----");
displayGrades();

console.log("\n----- Updating a grade -----");
updateGrade(2, 85);

console.log("\n----- Deleting a grade -----");
deleteGrade("Sara");
// You can also delete by ID, e.g. deleteGrade(1);

console.log("\n----- Final grades -----");
displayGrades();
